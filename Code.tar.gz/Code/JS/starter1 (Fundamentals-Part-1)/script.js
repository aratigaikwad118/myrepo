//challenge1
massMark = 78;
massJohn = 95;
heightMark = 1.69;
heightJohn = 1.88;
bmiMark = massMark / heightMark ** 2;
bmiJohn = massJohn / heightJohn ** 2;
console.log(bmiMark);
console.log(bmiJohn);
marhHigherBMI = bmiJohn < bmiMark;
console.log(marhHigherBMI);

//challenge2
if (bmiJohn > bmiMark) {
    console.log(`John's BMI ${bmiJohn} is Greater than Mark's BMI ${bmiMark} 😊`);
} else {
    console.log(`Mark's BMI ${bmiMark}  is Greater than John's BMI ${bmiJohn} 😊`);
}

//challenge3
scoreDolphins = (96 + 108 + 89) / 3;
scoreKoalas = (88 + 91 + 110) / 3;
if (scoreDolphins > scoreKoalas)
    console.log("Dolphin is Winner");
else if (scoreDolphins < scoreKoalas)
    console.log("Kialas is Winner");
else
    console.log("Match Draw")

scoreDolphins = (97 + 112 + 101) / 3;
scoreKoalas = (109 + 95 + 123) / 3;
if (scoreDolphins > scoreKoalas && scoreDolphins >= 100)
    console.log("Dolphin is Winner...😎");
else if (scoreDolphins < scoreKoalas && scoreKoalas >= 100)
    console.log("Kialas is Winner...😎");
else if (scoreDolphins === scoreKoalas && scoreDolphins >= 100 && scoreKoalas >= 100)
    console.log("Match Draw...😁")
else
    console.log("No one won trophy...😒")

//challenge4
billValue = 52;

let str = billValue <= 300 && billValue >= 50 ? `the billvalue is ${billValue} and the tip is ${billValue * (0.15)} so total amount is ${billValue + billValue * (0.15)}` : `the billvalue is ${billValue} and the tip is ${billValue * (0.2)} so total amount is ${billValue + billValue * (0.2)}`;
console.log(str);
/*
var a = 'js is really amazing';
alert(a);

console.log(40 + 20 - 8 - 2);

const country = 'India';
const continent = 'Asia';
let population = 135;
population++;
isIceland = true;
let language = 'Marathi';
console.log(country);
console.log(continent);
console.log(population);
console.log(population / 2);
console.log(typeof country);
console.log(typeof continent);
console.log(typeof population);
console.log(typeof isIceland);
console.log(typeof language);
ans = population > 33;
console.log(ans);
sam = country + ' is in ' + continent + ', and its ' + population + ' million people speak ' + language;
console.log(sam);
const description = `${country} is in ${continent}, and its
${population} million people speak ${language}`;
console.log(description);
*/
