'use strict';

//challenge1
const game = {
  team1: 'Bayern Munich',
  team2: 'Borrussia Dortmund',
  players: [
  [
  'Neuer',
  'Pavard',
  'Martinez',
  'Alaba',
  'Davies',
  'Kimmich',
  'Goretzka',
  'Coman',
  'Muller',
  'Gnarby',
  'Lewandowski',
  ],
  [
  'Burki',
  'Schulz',
  'Hummels',
  'Akanji',
  'Hakimi',
  'Weigl',
  'Witsel',
  'Hazard',
 'Brandt',
 'Sancho',
 'Gotze',
 ],
 ],
 score: '4:0',
 scored: ['Lewandowski', 'Gnarby', 'Lewandowski',
 'Hummels'],
 date: 'Nov 9th, 2037',
 odds: {
 team1: 1.33,
 x: 3.25,
 team2 :6.5,
},
}

const [player1,player2]=game.players;
const [gk ,...feildplayers]=[...player1];
const allPlayers=[...player1,...player2];
const players1Final=[...player1,'Thiago', 'Coutinho','Perisic'];
const {odds:{
  team1, 
  x=draw,
  team2 },}=game;

  const printGoals=function(arr){
    console.log(typeof arr);
    const size=arr.length;
    console.log(`${size} players scored`);
    arr.forEach(element => {
      console.log(element);
    });
  }
  printGoals(['Lewandowski', 'Gnarby', 'Lewandowski',
  'Hummels']);
  team1<team2 && console.log('team1 wins');
  team1>team2 && console.log('team2 wins');

/*
const restaurant = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  openingHours: {
    thu: {
      open: 12,
      close: 22,
    },
    fri: {
      open: 11,
      close: 23,
    },
    sat: {
      open: 0, // Open 24 hours
      close: 24,
    },
  },
};
*/