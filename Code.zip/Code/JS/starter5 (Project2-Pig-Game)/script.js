const newBtn=document.querySelector('.btn--new');
const diceBtn=document.querySelector('.btn--roll');
const holdBtn=document.querySelector('.btn--hold');
const imgDice=document.querySelector('.dice');

const player0=document.querySelector('.player--0');
const player1=document.querySelector('.player--1');
let totalScore0=document.getElementById('score--0');
let totalScore1=document.getElementById('score--1');
let currentScore0=document.getElementById('current--0');
let currentScore1=document.getElementById('current--1');

let Score,activePlayer,currentScore,playing;
const init=function(){
    imgDice.classList.add('hidden');
    player0.classList.remove('player--winner');
    player1.classList.remove('player--winner');      
    player0.classList.add('player--active');  
    player1.classList.remove('player--active');  
    currentScore0.textContent=0;
    currentScore1.textContent=0;
    totalScore0.textContent=0;
    totalScore1.textContent=0;
    Score=[0,0];
    activePlayer=0;
    currentScore=0;
    playing=true; 
    
}
init();
newBtn.addEventListener('click',init);

const switchPlayer=function(){
    currentScore=0;
    document.getElementById(`current--${activePlayer}`).textContent=0;
    activePlayer=activePlayer === 0 ? 1:0;
    player0.classList.toggle('player--active');
    player1.classList.toggle('player--active');
}
diceBtn.addEventListener('click',function(){
    if(playing){
    const randNo=Math.trunc(Math.random()*6+1);
    imgDice.src=`dice-${randNo}.png`;
    console.log(randNo);

    if(randNo!=1){
        imgDice.classList.remove('hidden');
        currentScore=currentScore+randNo;
        document.getElementById(`current--${activePlayer}`).textContent=currentScore;
    }else{
        document.getElementById(`score--${activePlayer}`).textContent=0;
        Score[activePlayer]=0;
        switchPlayer();
        }
    }
})

    holdBtn.addEventListener('click',function(){
        if(playing){
        Score[activePlayer]+=currentScore;
        document.getElementById(`score--${activePlayer}`).textContent=Score[activePlayer];
        if (Score[activePlayer] >= 10) {
            playing=false;
            //console.log('hii');
            document
            .querySelector(`.player--${activePlayer}`)
            .classList.add('player--winner');
          document
            .querySelector(`.player--${activePlayer}`)
            .classList.remove('player--active');
        }
        else{
            switchPlayer();
        }
    }
    })  
const myAge={
    year:1998,
    calcAge:function(){
        return 2020-this.year;
    }
} 
const myInfo={
    myName:'aaru',
}
myInfo.lastName='Gaikwad';
myInfo.age=myAge.calcAge();
console.log(myInfo);
for(let i=0;i<20;i++){
    console.log("hiii");
}

