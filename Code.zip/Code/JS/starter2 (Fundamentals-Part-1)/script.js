'use strict';
//challenge1
const calcAvarage = (score1, score2, score3) => (score1 + score2 + score3) / 3;

const avgDolphins = calcAvarage(44, 23, 71);
const avgKoalase = calcAvarage(65, 54, 49);
const checkWinner = function (avgDolphins, avgKoalase) {
    if (avgDolphins >= 2 * avgKoalase)
        console.log(`Dolphin win (${avgDolphins} vs ${avgKoalase})`);
    else if (avgKoalase >= 2 * avgDolphins)
        console.log(`Koalse win (${avgDolphins} vs ${avgKoalase})`);
    else
        console.log(`Koalse win (${avgDolphins} vs ${avgKoalase})`);
}
checkWinner(avgDolphins, avgKoalase);
//chalenge2
const calcTip = function (billValue) {
    if (billValue >= 50 && billValue <= 300)
        return billValue * 0.15;
    else if (billValue > 300)
        return billValue * 0.2;
    else
        return 0;
}
const bills1 = [155, 545, 44];
const tips1 = [calcTip(bills1[0]), calcTip(bills1[1]), calcTip(bills1[2])];
console.log(tips1);
const total = [bills1[0] + tips1[0], bills1[0] + tips1[0], bills1[0] + tips1[0]];
console.log(total);

//chalenge3
const objJohn = {
    name: 'John',
    weight: 78,
    height: 1.69,
    calcBMI: function () {
        return this.weight / (this.height ** 2);
    }
};
const objMark = {
    name: 'Mark',
    weight: 95,
    height: 1.95,
    calcBMI: function () {
        return this.weight / (this.height ** 2);
    }
};
if (objJohn.calcBMI > objMark.calcBMI)
    console.log(`${objJohn.name} has higher BMI ${objJohn.calcBMI()} than ${objMark.name}'s BMI ${objMark.calcBMI()}`);
else
    console.log(`${objMark.name} has higher BMI ${objMark.calcBMI()} than ${objJohn.name}'s BMI ${objJohn.calcBMI()}`);

//chalenge4
const bills = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52];
const tip = function (billValue) {
    return billValue >= 50 && billValue <= 300 ? billValue * 0.15 : billValue > 300 ? billValue * 0.2 : 0;
}
const tips = [];
const totalTip = [];
for (let i = 0; i < 10; i++) {
    tips.push(tip(bills[i]));
    totalTip.push(bills[i] + tip(bills[i]));
}
console.log(tips);
console.log(totalTip);

const calcAvg = function (arr) {
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
        sum = sum + arr[i];
    }
    return sum / arr.length;
}

console.log('Avg is ' + calcAvg(total));
/*let driver = true;
let myname = false;
if (driver) myane = true;
//else myname = false;

console.log(myname);*/