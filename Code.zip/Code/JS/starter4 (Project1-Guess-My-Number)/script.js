'use strict';
const secreteNo=Math.trunc(Math.random()*20)+1;
let score=20;
if(score>0){
document.querySelector('.check').addEventListener('click',function(){
    score--;
    const guessNo=Number(document.querySelector('.guess').value);
    console.log(guessNo,typeof guessNo);
    if(score>0){
        if(!guessNo){
            document.querySelector('.message').textContent='No Nummber 😐';
            document.querySelector('.score').textContent=score;
        }else if(guessNo === secreteNo){
            document.querySelector('.message').textContent='Yeah you got that 🤩';
            document.querySelector('.score').textContent=score;
            if(document.querySelector('.highscore').textContent < score) {
                document.querySelector('.highscore').textContent=score;
                document.querySelector('.number').textContent=secreteNo;
                document.querySelector('body').style.backgroundColor='green';

            }
            
        }else if(guessNo > secreteNo){
            document.querySelector('.message').textContent='Too high 😮';     
        }else if(guessNo<secreteNo){
            document.querySelector('.message').textContent='Too low 😣';
            document.querySelector('.score').textContent=score;
        }
    }else{
        document.querySelector('.score').textContent=score;
        document.querySelector('.message').textContent='You Lost 😭';
        }
})
}
document.querySelector('.again').addEventListener('click',function(){
    document.querySelector('.score').textContent=20;
    document.querySelector('.message').textContent='Start guessing...';
    document.querySelector('.guess').value='';
    document.querySelector('.number').textContent='?';
})